Low-angle hero
From MiniMax H3 camera shots, Part 2
https://loopforge.cc/projects/h3-camera-shots/low-angle-hero/

IN THIS ZIP

  low-angle-hero.json  the ComfyUI workflow for this shot, with the prompt, seed and settings it ran with
  raven.png  the character reference plate it loads as <Picture 1>

HOW TO RUN IT

  1. Copy raven.png into ComfyUI/input, keeping its name.
  2. Download the models below into the ComfyUI/models subfolders shown.
  3. Drag low-angle-hero.json onto the ComfyUI window, or open it from the Workflow menu.
  4. Queue it. The result is saved under ComfyUI/output/video/h3-camera-shots/.
     With the same model files you should get the same shot or a very close one; different GPUs can drift a little.

MODELS

  From https://huggingface.co/Comfy-Org/MiniMax-H3

  models/diffusion_models/minimax_h3_ref2va_pruned_int8_convrot.safetensors  (21.0 GB)
  models/text_encoders/qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors  (15.7 GB)
  models/vae/minimax_h3_video_vae_fp16.safetensors  (5.2 GB)
  models/vae/minimax_h3_audio_vae_fp32.safetensors  (0.6 GB)

  The workflow is ComfyUI's own MiniMax H3 reference-to-video template with this shot's settings
  filled in. It ran with the fp16 video VAE; the template normally uses the smaller int8 one.

SOFTWARE

  ComfyUI 0.41.0 or newer. No custom nodes: every node in this graph is part of ComfyUI.

WHAT I RAN IT ON

  RTX 3060, 12GB (local), 20 steps, about 21 minutes for this clip.
