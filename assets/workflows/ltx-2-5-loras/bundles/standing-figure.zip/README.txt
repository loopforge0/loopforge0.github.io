Standing figure
From LTX 2.5 Creative Lab LoRAs, tested locally
https://loopforge.cc/projects/ltx-2-5-loras/standing-figure/

IN THIS ZIP

  standing-figure.json  ComfyUI workflow with this test's settings
  standing-figure-no-lora.json  ComfyUI workflow with this test's settings
  char_allie.png  input the workflow loads

HOW TO RUN IT

  1. Copy the input files into ComfyUI/input, keeping their names.
  2. Download the models below into the ComfyUI/models subfolders shown.
  3. Drag the workflow .json onto the ComfyUI window, or open it from the Workflow menu.
     The prompt and the settings (Shorter side for the size, the length, the seed) are on the
     subgraph nodes; the note in the workflow says how to run it on your own footage. It needs
     ComfyUI 0.37 or newer. If any node shows up red, update ComfyUI or ComfyUI-LTXVideo
     to the commit below rather than rewiring the graph.
  4. Queue it. The result is saved under ComfyUI/output/video/ltx-2-5-loras/.

MODELS

  models/diffusion_models/ltx-2.5-22b-distilled-transformer-comfy-int8-convrot.safetensors  (21.5 GB)
    https://huggingface.co/Lightricks/LTX-2.5/resolve/main/diffusion_models/ltx-2.5-22b-distilled-transformer-comfy-int8-convrot.safetensors
  models/text_encoders/gemma4-12b-with-proj-ltx-2.5-comfy-int8-convrot.safetensors  (15.4 GB)
    https://huggingface.co/Lightricks/LTX-2.5/resolve/main/text_encoders/gemma4-12b-with-proj-ltx-2.5-comfy-int8-convrot.safetensors
  models/vae/ltx-2.5-video-vae-bf16.safetensors  (1.5 GB)
    https://huggingface.co/Lightricks/LTX-2.5/resolve/main/vae/ltx-2.5-video-vae-bf16.safetensors
  models/vae/ltx-2.5-audio-vae-bf16.safetensors  (365 MB)
    https://huggingface.co/Lightricks/LTX-2.5/resolve/main/vae/ltx-2.5-audio-vae-bf16.safetensors
  models/loras/ltx-2.5-22b-lora-cinemagraph-0.9.safetensors  (201 MB)
    https://huggingface.co/Lightricks/LTX-2.5-22b-LoRA-Cinemagraph/resolve/main/ltx-2.5-22b-lora-cinemagraph-0.9.safetensors

  The Lightricks repositories on Hugging Face (the base model and every LoRA) are gated. Log in, open each
  repository page and accept its terms first, or the download links return an error.

SOFTWARE

  ComfyUI 0.37.0 (commit 0f74f7fb, frontend 1.53.6)
  No custom nodes. Every node in this workflow is part of ComfyUI itself.

WHAT I RAN IT ON

  An RTX 3060 with 12GB, i5-13400F and 32GB RAM. Generated in 6 min, peak VRAM 11.4 GiB.
