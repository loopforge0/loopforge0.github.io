Park with fountain
From LTX 2.5 Creative Lab LoRAs, tested locally
https://loopforge.cc/projects/ltx-2-5-loras/park-with-fountain/

IN THIS ZIP

  park-with-fountain.json  ComfyUI workflow, API format, exactly as it ran
  src2_day_park_hd.mp4  input the workflow loads

HOW TO RUN IT

  1. Copy the input files into ComfyUI/input, keeping their names.
  2. Download the models below into the ComfyUI/models subfolders shown.
  3. Drag the workflow .json onto the ComfyUI window, or open it from the Workflow menu.
     It is in API format. The ComfyUI frontend I used (1.53.6) opens that directly and
     lays the nodes out itself, so the graph looks plain but runs the same.
  4. Queue it. The result is saved under ComfyUI/output/video/ltx-2-5-loras/.

MODELS

  models/diffusion_models/ltx-2.5-22b-distilled-transformer-comfy-int8-convrot.safetensors  (21.5 GB)
    https://huggingface.co/Lightricks/LTX-2.5/resolve/main/diffusion_models/ltx-2.5-22b-distilled-transformer-comfy-int8-convrot.safetensors
  models/text_encoders/gemma4-12b-with-proj-ltx-2.5-comfy-int8-convrot.safetensors  (15.4 GB)
    https://huggingface.co/Lightricks/LTX-2.5/resolve/main/text_encoders/gemma4-12b-with-proj-ltx-2.5-comfy-int8-convrot.safetensors
  models/vae/ltx-2.5-video-vae-bf16.safetensors  (1.5 GB)
    https://huggingface.co/Lightricks/LTX-2.5/resolve/main/vae/ltx-2.5-video-vae-bf16.safetensors
  models/vae/ltx-2.5-audio-vae-bf16.safetensors  (365 MB)
    https://huggingface.co/Lightricks/LTX-2.5/resolve/main/vae/ltx-2.5-audio-vae-bf16.safetensors
  models/loras/ltx-2.5-22b-ic-lora-day-to-night-0.9.safetensors  (327 MB)
    https://huggingface.co/Lightricks/LTX-2.5-22b-IC-LoRA-Day-To-Night/resolve/main/ltx-2.5-22b-ic-lora-day-to-night-0.9.safetensors

  The Lightricks repositories on Hugging Face (the base model and every LoRA) are gated. Log in, open each
  repository page and accept its terms first, or the download links return an error.

SOFTWARE

  ComfyUI 0.37.0 (commit 0f74f7fb, frontend 1.53.6)
  ComfyUI-LTXVideo at commit 3bf3ca6
    https://github.com/Lightricks/ComfyUI-LTXVideo/tree/3bf3ca62595f1764c47d01c35c8e5dfe47e1a88f

WHAT I RAN IT ON

  An RTX 3060 with 12GB, i5-13400F and 32GB RAM. Generated in 10 min, peak VRAM 10.9 GiB.
