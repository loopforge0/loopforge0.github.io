Anime2Real: Freya
=================

From the Loop Forge project "MOSS-Image add-ons, tested locally": https://loopforge.cc/projects/moss-image/anime2real-freya/

What is in here
- 2 ComfyUI workflow file(s), the one that made each image on the test page
- inputs/: every image the workflows load, under the name they load it by

To run it
1. Copy the files in inputs/ into ComfyUI/input.
2. Put the models below in the ComfyUI/models folders shown.
3. Drag a workflow onto ComfyUI and press Run.

Models
- moss_image_sft_int8_convrot.safetensors -> models/diffusion_models (https://huggingface.co/Comfy-Org/MOSS-Image/resolve/main/diffusion_models/moss_image_sft_int8_convrot.safetensors)
- Moss_SFT_Edit_A2R_v1_000006000.safetensors -> models/loras (https://civitai.com/models/3009913)
- qwen3.5_9b_w4a8_gptq.safetensors -> models/text_encoders (https://huggingface.co/Comfy-Org/MOSS-Image/resolve/main/text_encoders/qwen3.5_9b_w4a8_gptq.safetensors)
- flux2-vae_small.safetensors -> models/vae (https://huggingface.co/Comfy-Org/MOSS-Image/resolve/main/vae/flux2-vae_small.safetensors)
- manba_real2anime_a2r_v1.safetensors (published as real2anime.safetensors, renamed) -> models/loras (https://civitai.com/models/3007986)

No custom nodes: every node is part of ComfyUI.

Made and tested with ComfyUI 0.43.1 (frontend 1.57.6, templates 0.11.100).
